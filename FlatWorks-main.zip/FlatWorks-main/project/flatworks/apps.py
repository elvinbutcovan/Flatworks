from django.apps import AppConfig


class FlatworksConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'flatworks'
